<?php
header('Content-Type: application/json');

// Forbind til SQLite-databasen
$db = new SQLite3('data/charging_data.db');

// Hent start- og slutdato fra GET-parametre (format: YYYY-MM-DD)
$startDate = isset($_GET['startDate']) ? $_GET['startDate'] : null;
$endDate   = isset($_GET['endDate']) ? $_GET['endDate'] : null;

// Konverter til timestamps hvis sat
$startTimestamp = $startDate ? strtotime($startDate . " 00:00:00") : null;
$endTimestamp   = $endDate ? strtotime($endDate . " 23:59:59") : null;

// Hent vehicle_charges inden for den valgte periode
$query = "SELECT vehicleId, cablePluggedInAt, odometer, chargeType FROM vehicle_charges";
if ($startTimestamp && $endTimestamp) {
    $query .= " WHERE strftime('%s', cablePluggedInAt) BETWEEN $startTimestamp AND $endTimestamp";
}
$query .= " ORDER BY vehicleId, cablePluggedInAt";
$vehicleChargesResult = $db->query($query);

// Hent all_charges inden for perioden
$query2 = "SELECT vehicleId, datetime, kwh, pris FROM all_charges";
if ($startTimestamp && $endTimestamp) {
    $query2 .= " WHERE strftime('%s', datetime) BETWEEN $startTimestamp AND $endTimestamp";
}
$query2 .= " ORDER BY vehicleId, datetime";
$allChargesResult = $db->query($query2);

// Konverter resultater til arrays
$vehicleCharges = [];
while ($row = $vehicleChargesResult->fetchArray(SQLITE3_ASSOC)) {
    $row['cablePluggedInAt'] = strtotime($row['cablePluggedInAt']);
    $vehicleCharges[] = $row;
}

$allCharges = [];
while ($row = $allChargesResult->fetchArray(SQLITE3_ASSOC)) {
    $row['datetime'] = strtotime($row['datetime']);
    $allCharges[] = $row;
}

$db->close();

// Hjælpefunktion til at finde nærmeste opladning i all_charges
function findNearestCharge($vehicleId, $timestamp, $allCharges) {
    $nearest = null;
    $minDiff = PHP_INT_MAX;
    foreach ($allCharges as $charge) {
        if ($charge['vehicleId'] == $vehicleId) {
            $diff = abs($charge['datetime'] - $timestamp);
            if ($diff < $minDiff) {
                $minDiff = $diff;
                $nearest = $charge;
            }
        }
    }
    return $nearest;
}

// Variabler til løbende summer per bil
$results = [];
$runningKm = [];
$runningKwh = [];
$runningPris = [];

foreach ($vehicleCharges as $index => $charge) {
    $vehicleId = $charge['vehicleId'];
    $timestamp = $charge['cablePluggedInAt'];

    // Find den nærmeste opladning
    $nearestCharge = findNearestCharge($vehicleId, $timestamp, $allCharges);
    
    if ($nearestCharge) {
        $kwh  = $nearestCharge['kwh'];
        $pris = $nearestCharge['pris'];

        // Beregn km kørt siden sidste måling for samme bil
        if ($index > 0 && $vehicleCharges[$index - 1]['vehicleId'] == $vehicleId) {
            $kmDriven = $charge['odometer'] - $vehicleCharges[$index - 1]['odometer'];
        } else {
            $kmDriven = 0;
        }

        // Initialiser summer for denne bil, hvis ikke sat
        if (!isset($runningKm[$vehicleId])) {
            $runningKm[$vehicleId]   = 0;
            $runningKwh[$vehicleId]  = 0;
            $runningPris[$vehicleId] = 0;
        }

        $runningKm[$vehicleId]   += $kmDriven;
        $runningKwh[$vehicleId]  += $kwh;
        $runningPris[$vehicleId] += $pris;

        // Beregn gennemsnit
        $kmPerKwh = $runningKwh[$vehicleId] > 0 ? round($runningKm[$vehicleId] / $runningKwh[$vehicleId], 2) : null;
        $krPerKm  = $runningKm[$vehicleId] > 0 ? round($runningPris[$vehicleId] / $runningKm[$vehicleId], 2) : null;

        // Gem resultaterne – du kan evt. tilpasse strukturen, så den passer til dine grafer
        $results[] = [
            'vehicleId'  => $vehicleId,
            'timestamp'  => $timestamp,
            'date'       => date('Y-m-d H:i', $timestamp),
            'kmDriven'   => $kmDriven,
            'totalKm'    => $runningKm[$vehicleId],
            'kmPerKwh'   => $kmPerKwh,
            'krPerKm'    => $krPerKm
        ];
    }
}

echo json_encode($results);
?>
