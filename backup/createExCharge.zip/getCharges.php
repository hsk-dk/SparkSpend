<?php
header('Content-Type: application/json');

try {
    $db = new PDO('sqlite:charging_data.db');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Hent filtre fra forespørgslen
    $filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
    $showZeroKwh = isset($_GET['showZeroKwh']) && $_GET['showZeroKwh'] === 'true';
	$dateRange = isset($_GET['dateRange']) ? explode(' to ', $_GET['dateRange']) : [];
	$startDate = isset($dateRange[0]) ? $dateRange[0] : null;
	$endDate = isset($dateRange[1]) ? $dateRange[1] : null;
    
    // Byg SQL-forespørgslen dynamisk
    $query = "SELECT * FROM charges WHERE 1=1";
    $params = [];

    if ($filter !== 'all') {
        $query .= " AND vehicleId = :vehicleId";
        $params[':vehicleId'] = $filter;
    }

    if (!$showZeroKwh) {
        $query .= " AND consumedKwh > 0";
    }

    if ($startDate && $endDate) {
		$query .= " AND datetime(createdAt) BETWEEN datetime(:startDate) AND datetime(:endDate)";
        $params[':startDate'] = $startDate . " 00:00:00";
        $params[':endDate'] = $endDate . " 23:59:59";
    }
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $charges = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($charges);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
	