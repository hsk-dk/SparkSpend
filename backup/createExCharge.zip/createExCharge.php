<?php
header('Content-Type: application/json');

$db = new SQLite3('charging_data.db');

$vehicleId   = isset($_POST['vehicleId']) ? $_POST['vehicleId'] : '';
$providerId  = isset($_POST['providerId']) ? $_POST['providerId'] : '';
$chargeDate  = isset($_POST['chargeDate']) ? $_POST['chargeDate'] : '';
$consumedKwh = isset($_POST['consumedKwh']) ? $_POST['consumedKwh'] : '';
$cost        = isset($_POST['cost']) ? $_POST['cost'] : '';

if (!$vehicleId || !$providerId || !$chargeDate || !$consumedKwh || !$cost) {
    echo json_encode(['success' => false, 'error' => 'Alle felter skal udfyldes']);
    exit;
}

$stmt = $db->prepare("INSERT INTO charges (vehicleId, providerId, createdAt, consumedKwh, cost) VALUES (:vehicleId, :providerId, :createdAt, :consumedKwh, :cost)");
$stmt->bindValue(':vehicleId', intval($vehicleId), SQLITE3_INTEGER);
$stmt->bindValue(':providerId', intval($providerId), SQLITE3_INTEGER);
$stmt->bindValue(':createdAt', $chargeDate);
$stmt->bindValue(':consumedKwh', floatval($consumedKwh));
$stmt->bindValue(':cost', floatval($cost));

$result = $stmt->execute();

if ($result) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Fejl ved oprettelse']);
}
?>
